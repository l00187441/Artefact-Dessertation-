export enum Role {
  USER = "user",
  LIBRARIAN = "librarian",
}
